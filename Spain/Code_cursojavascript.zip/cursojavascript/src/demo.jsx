/**
 * Created by drm2ss on 25/01/2017.
 */
import React, {PropTypes} from 'react'
export default class Avatar extends React.Component {
    render() {
        return (
            <div className="xxx">
                <p>
                 <em>{this.props.email}</em>
                </p>
            </div>
        );
    }
}

Avatar.propTypes = {
    email: PropTypes.string,
    src: PropTypes.string,
};