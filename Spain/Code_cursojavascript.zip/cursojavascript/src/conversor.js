/**
 * Created by drm2ss on 25/01/2017.
 */

exports.rgbToHex = function(rojo, verde, azul) {

    var rojoHex = rojo.toString(16);
    var verdeHex = verde.toString(16);
    var azulHex = azul.toString(16);

    return pad(rojoHex) + pad(verdeHex) + pad(azulHex);
};

function pad(hex) {
    return (hex.length === 1 ? "0" + hex : hex);
}

