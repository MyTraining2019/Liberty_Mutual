/**
 * Created by drm2ss on 25/01/2017.
 */


var assert = require('assert');
var conversor = require('../src/conversor');

describe('Demo1', function() { // Test Suite principal

    describe('Tests booleanos', function() { // Test Suite secundaria

        it('Probar true', function() {

            assert.equal(1==1, true);

        })

        it('Probar true', function() {

            assert.equal(1==='1', false);

        })

        it('Probar conversión', function() {

            var rojoHex = conversor.rgbToHex(255,0,0);
            assert.equal(rojoHex, "ff0000", "Esperaba FF0000");
        })


    });

});
