/**
 * Created by drm2ss on 25/01/2017.
 */

import React from 'react'

const MapaComponent = (props) => {
    return (
        <div data-info="Liberty" className="google">
            <p>{props.continente}</p>
        </div>
    );
}

export default MapaComponent;