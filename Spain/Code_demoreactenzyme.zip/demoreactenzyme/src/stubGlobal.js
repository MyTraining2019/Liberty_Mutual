/**
 * Created by drm2ss on 27/01/2017.
 */
import React from "react";

var elementoOriginal = React.createElement;
var divFactory = React.createFactory('div');

module.exports = function(sandbox) {

    return {
        stubHijo: function(stubbedComponents) {
            sandbox.stub(React, 'createElement', function (component, props) {
                if (stubbedComponents.indexOf(component) === -1) {
                    return elementoOriginal.apply(React, arguments);
                }
                else {
                    var componentFactory = React.createFactory(component);
                    var nombre = componentFactory().type;
                    if (nombre) {
                        props.className = nombre;
                    }

                    return divFactory(props);

                }
            });
        }
    }
};

