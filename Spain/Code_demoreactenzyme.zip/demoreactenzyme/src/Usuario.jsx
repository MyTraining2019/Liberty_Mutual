/**
 * Created by drm2ss on 26/01/2017.
 */
import React from 'react'

var usuario = React.createClass({
    propTypes: {
        email: React.PropTypes.string,
        foto: React.PropTypes.string
    },
    defaultProps: {
        email: "pepe@correo.es",
        foto: "mifoto.png"
    },
    render: function() {
        return (<div><button></button>
        </div>);
    }
});

export default usuario