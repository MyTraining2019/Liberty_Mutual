/**
 * Created by drm2ss on 27/01/2017.
 */
import {Provider} from 'react-redux';

export function crearReducer(estadoInicial, reducerMap) {
    return (state = estadoInicial, action) => {
        const reducer = reducerMap[action.type];

        return reducer ? reducer(state, action.payload) : state;
    };
}

