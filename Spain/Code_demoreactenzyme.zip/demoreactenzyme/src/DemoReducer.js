/**
 * Created by drm2ss on 27/01/2017.
 */
import {crearReducer} from './auxReducers';

const estadoInicial = {contador: 0};

export default crearReducer(estadoInicial, {
    ['INCREMENTAR']: (state) => ({contador: state.contador+1}),
    ['DECREMENTAR']: (state) => ({contador: state.contador-1}),
});