/**
 * Created by drm2ss on 27/01/2017.
 */
import {Provider} from 'react-redux';

export function createReducer(estadoInicial, mapReducer) {
    return (state = estadoInicial, action) => {
        const reducer = mapReducer[action.type];

        return reducer ? reducer(state, action.payload) : state;
    };
}