/**
 * Created by drm2ss on 26/01/2017.
 */
import React from 'react'

const DemoReact = (props) => {
    return (
        <div>
            <span className="cabecera">Título</span>
            <div foo="bar"/>
        </div>
    );
}

export default DemoReact;

