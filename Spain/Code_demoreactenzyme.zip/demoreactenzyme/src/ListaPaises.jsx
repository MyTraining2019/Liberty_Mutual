/**
 * Created by drm2ss on 25/01/2017.
 */

import React from 'react'

class ListaPaises extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            paises: []
        };
    }
    render() {
        if (this.state.paises.length == 0)
        {
            return null;
        }

        return (<div>{this._construirLista()}</div>);
    }

    _construirLista() {
        return this.state.paises.map((pais) => {
            return (
                <MapaComponent
                    continente="Europa"
                    pais={pais.nombre}
                    codigo={pais.codigo}/>
            );
        });
    }

}

export default ListaPaises;