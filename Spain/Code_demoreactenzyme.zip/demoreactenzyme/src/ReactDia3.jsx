/**
 * Created by drm2ss on 27/01/2017.
 */
import React, {PropTypes} from "react"

var Componente1 = React.createClass({ propTypes: {className:PropTypes.string},
   nombre: "COMP1",
    render: function() {
        return (<div>{nombre} Soy el componente 1</div>);
    }
});

export default Componente1;