/**
 * Created by drm2ss on 26/01/2017.
 */
var jquery = require('jquery');

exports.unica = function unica(fn) {
    var resultado, llamada = false;
    return function() {
      if (!llamada) {
          llamada = true;
          resultado = fn.apply(this, arguments);
      }
        return resultado;
    };
};

exports.obtenerCliente = function obtenerCliente(id, callback) {
    jquery.ajax({
       url: "/clientes/" + id + "/detalles",
        success: function(data) {
            callback(null, data);
        }
    });
};
