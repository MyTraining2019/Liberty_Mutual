# tdd-react-enzyme-article

A repo for the [A TDD approach on testing React components using Enzyme](http://thereignn.ghost.io/a-step-by-step-tdd-approach-on-testing-react-components-using-enzyme/) I wrote.

### Usage

1. Clone the repo
2. Run `npm install`
3. Run `npm test`
