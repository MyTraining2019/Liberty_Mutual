/**
 * Created by drm2ss on 27/01/2017.
 */
import {expect} from 'chai';
import reducer from '../src/DemoReducer';

describe('Pruebas Reducer', function() {
   it('Prueba incremento', () => {
       const estadoInicial = {contador: 0};

       const nuevoEstado = reducer(estadoInicial, {type: 'INCREMENTAR'});

       expect(nuevoEstado).to.eql({contador: 1});
   }) ;

    it('Prueba decremento', () => {
        const estadoInicial = {contador: 10};

        const nuevoEstado = reducer(estadoInicial, {type: 'DECREMENTAR'});

        expect(nuevoEstado).to.eql({contador: 9});
    }) ;
});