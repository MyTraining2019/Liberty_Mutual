/**
 * Created by drm2ss on 25/01/2017.
 */

import React from 'react'
import { expect } from 'chai'
import { shallow, mount, render } from 'enzyme'

import ListaPaises from '../src/ListaPaises'

let wrapper;

describe('Test Suite Países Mount', () => {
   beforeEach(() => {
        wrapper = mount(<ListaPaises />);
    });

    it('Verificar que hay listado de países', () => {
        expect(wrapper.state().paises).to.be.instanceOf(Array);
        expect(wrapper.state().paises.length).to.equal(0);
        expect(wrapper.html()).to.equal(null);
    });

});