/**
 * Created by drm2ss on 27/01/2017.
 */

import sinon from "sinon"
import Componente1 from "../src/ReactDia3";
import Componente2 from "../src/ReactDia3";
import React from "react";
import StubGlobal from '../src/stubGlobal';
import {expect} from 'chai';

import { shallow, mount, render } from 'enzyme'

/* var ReactAddons = require("react/addons");
var TestUtils = ReactAddons.addons.TestUtils;
var Sinon = require("sinon");
var ReactSpecHelper = require("specHelpers/ReactSpecHelper");
var Componente1 = require("../src/ReactDia3");*/

var sandbox;

describe("Tests del día 3", function() {

    beforeEach(function() {
        sandbox = sinon.sandbox.create();
        console.log(sandbox);
        new StubGlobal(sandbox).stubHijo([Componente2]);
    });

    afterEach(function() {
       sandbox.restore();
    });

   it("Test Componente 1", function() {
       var componente = React.createElement("Componente1", {});
       //var componente = mount(<Componente1/>);
       console.log("HTML1", componente.type);
       expect(componente.type).to.equal("Componente1");
   });

    it("Test Componente 2", function() {
        var componente = React.createElement("Componente2", {});
        //var componente = mount(<Componente2/>);
        expect(componente.type).to.equal("Componente2");
    });
});
