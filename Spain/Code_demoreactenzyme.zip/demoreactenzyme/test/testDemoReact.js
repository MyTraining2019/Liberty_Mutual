/**
 * Created by drm2ss on 26/01/2017.
 */

import ReactTestUtils from 'react-addons-test-utils'
import React from 'react'
import DemoReact from '../src/DemoReact'
import {expect} from 'chai'

const renderer = ReactTestUtils.createRenderer();
renderer.render(<DemoReact/>);
const objeto = renderer.getRenderOutput();

describe('React Test Utils Suite', function() {
   it('Test 1', function() {
      expect(objeto.type).to.equal('div');
       console.log(objeto.props.children);
       expect(objeto.props.children[0].props.className).to.equal("cabecera");
   });

});
