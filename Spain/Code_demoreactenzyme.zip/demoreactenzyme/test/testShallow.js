/**
 * Created by drm2ss on 25/01/2017.
 */

import React from 'react'
import { expect } from 'chai'
import { shallow, mount, render } from 'enzyme'

import Mapa from '../src/MapaComponent'

describe('Demo Test Suite React Shallow', () => {
   it('Componente Mapa existe', () => {
      let wrapper = shallow(<Mapa />)
       expect(wrapper).to.exist;
   });

    it('Componente Mapa muestra div', () => {
        let wrapper = shallow(<Mapa continente={'Europa'} />)
        expect(wrapper.type()).to.equal('div');
    });

    it('Componente Mapa muestra Europa', () => {
        let wrapper = shallow(<Mapa continente={'Europa'} />)
        let p = wrapper.childAt(0);
        expect(p.text()).to.equal('Europa');
    });

    it('Componente Mapa muestra Asia', () => {
        let wrapper = shallow(<Mapa continente={'Asia'} />)
        let p = wrapper.childAt(0);
        expect(p.text()).to.equal('Asia');
    });

    it('Componente Mapa muestra mapa Google', () => {
        let wrapper = shallow(<Mapa continente={'Asia'} />)
        expect(wrapper.hasClass('google')).to.equal(true);
        expect(wrapper.find('[data-info="Liberty"]')).to.exist;
    });


});