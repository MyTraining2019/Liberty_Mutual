/**
 * Created by drm2ss on 26/01/2017.
 */
import React from 'react'
import { expect } from 'chai'
import { shallow, mount, render } from 'enzyme'
import Usuario from '../src/Usuario'

describe('Test práctica 1', function() {
   it('Comprobar propiedades', function()
   {
       let wrapper = mount(<Usuario />) ;
       expect(wrapper.props().foto).to.be.equal("mifoto.png");
       expect(wrapper.instance().defaultProps.foto).to.equal("mifoto.png");
   });
   it('Simular click', function() {
       let wrapper = mount(<Usuario />);
       wrapper.find('input').set
       wrapper.find('button').simulate('click');


   })

});