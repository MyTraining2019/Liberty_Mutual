/**
 * Created by drm2ss on 26/01/2017.
 */

var demosinon = require("../src/demoSinon");
var sinon = require("sinon");
var assert = require("assert");
var jquery = require("jquery");

describe('Tests Sinon', function()
{
    it('Test Sinon llamada', function() {

        var callback = sinon.spy();
        var proxy = demosinon.unica(callback);

        proxy();

        assert(callback.called);

    });

    it('Test Sinon llamada 1 vez', function() {

        var callback = sinon.spy();
        var proxy = demosinon.unica(callback);

        proxy();
        proxy();

        assert(callback.calledOnce);

    });

    it('Test Sinon llamada con argumentos', function() {

        var callback = sinon.spy();
        var proxy = demosinon.unica(callback);
        var objeto = {};

        proxy.call(objeto, 1, 2, 3);
        assert(callback.calledOn(objeto));
        assert(callback.calledWith(1,2));

    });

    it('Hacer petición clientes AJAX', function() {
        sinon.stub(jquery, "ajax");
        demosinon.obtenerCliente(7, sinon.spy());
        assert(jquery.ajax.calledWithMatch({url: "/clientes/7/detalles"}));
        sinon.stub(jquery, "ajax").return("{'Pepe}")
    });

    var peticion;

    before(function() {
        peticion = sinon.useFakeXMLHttpRequest();
    });

    after(function() {
       peticion.restore();
    });

    it('XMLHTTP', function() {

    })

})
