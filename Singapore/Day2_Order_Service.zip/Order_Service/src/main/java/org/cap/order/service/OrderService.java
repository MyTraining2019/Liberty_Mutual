package org.cap.order.service;

import java.util.List;

import org.cap.common.ServiceException;
import org.cap.order.model.domain.OrderSummary;

public interface OrderService {

	List<OrderSummary> getOrderSummary(long customerId) throws ServiceException;
}
