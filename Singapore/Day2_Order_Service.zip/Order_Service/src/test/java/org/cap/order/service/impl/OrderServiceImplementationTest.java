package org.cap.order.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.cap.common.DataAccessException;
import org.cap.common.ServiceException;
import org.cap.order.dao.OrderDao;
import org.cap.order.model.entity.OrderEntity;
import org.cap.order.model.transformer.OrderEntityToOrderSummaryTransformer;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class OrderServiceImplementationTest {
	
	private final static long CUSTOMER_ID=1;
	
	private OrderServiceImpl target=null;
	
	@Mock
	protected OrderDao orderDao;
	@Mock
	protected OrderEntityToOrderSummaryTransformer mockTransfer;

	@Before
	public void setUp(){
		MockitoAnnotations.initMocks(this);
		
		this.target=new OrderServiceImpl();
		this.target.setOrderDao(orderDao);
		this.target.setTransformer(mockTransfer);
	}
	
	@Test
	public void test_openNewOrder_successfullyRetriesDataInsert() throws Exception {
		//declaration
		Mockito.when(orderDao.insert(Mockito.any(OrderEntity.class)))
		.thenThrow(new DataAccessException("First Ex"))
		.thenReturn(1);
		
		//Execution
		this.target.openNewOrder(CUSTOMER_ID);
		
		//Verification
		Mockito.verify(orderDao,Mockito.times(2)).insert(Mockito.any(OrderEntity.class));
	}
	
	@Test(expected=ServiceException.class)
	public void test_Open_newOrder_Fails_insertData() throws Exception{
		//Declaration
				Mockito.when(orderDao.insert(Mockito.any(OrderEntity.class)))
					.thenThrow(new DataAccessException("First Ex"))
					.thenThrow(new DataAccessException("Second Ex"));
				try{
				//Execution
				this.target.openNewOrder(CUSTOMER_ID);
				}finally {
					Mockito.verify(orderDao,Mockito.times(2))
						.insert(Mockito.any(OrderEntity.class));
				}
	}
	
		@Test
	public void test_Open_newOrder_Success() throws Exception{
		//Declaration
		Mockito.when(orderDao.insert(Mockito.any(OrderEntity.class))).thenReturn(1);
			
		
		//Execution
		String orderNumber=this.target.openNewOrder(CUSTOMER_ID);
		
		//Verification
		ArgumentCaptor<OrderEntity> orderEntityCaptor=ArgumentCaptor.forClass(OrderEntity.class);
		
		Mockito.verify(orderDao).insert(orderEntityCaptor.capture());
		
		OrderEntity orderEntityCapture=orderEntityCaptor.getValue();
		
		assertNotNull(orderEntityCapture);
		assertEquals(CUSTOMER_ID, orderEntityCapture.getCustomerId());
		assertEquals(orderNumber, orderEntityCapture.getOrderNumber());
	}
	
}
