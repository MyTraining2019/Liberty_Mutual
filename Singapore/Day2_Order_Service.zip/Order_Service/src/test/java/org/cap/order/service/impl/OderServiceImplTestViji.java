package org.cap.order.service.impl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.cap.common.DataAccessException;
import org.cap.common.ServiceException;
import org.cap.order.dao.OrderDao;
import org.cap.order.model.entity.OrderEntity;
import org.cap.order.model.transformer.OrderEntityToOrderSummaryTransformer;
import org.cap.order.service.OrderService;
import org.junit.Before;
import org.junit.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.core.classloader.annotations.MockPolicy;

public class OderServiceImplTestViji {
	
	private final int CUSTOMERID=1; 
	
	private OrderServiceImpl target =null;
	@Mock private OrderDao orderDao;
	@Mock private OrderEntityToOrderSummaryTransformer transformer;
	
	@Before
	public void setUp(){
		MockitoAnnotations.initMocks(this);
		target=new OrderServiceImpl();
		this.target.setOrderDao(orderDao);
		this.target.setTransformer(transformer);
		
	}
	
	
	/*@Test(expected=ServiceException.class)
	public void ttest_openNewOrder_failedDataInsert() throws Exception{
		Mockito.when(orderDao.insert(Mockito.any(OrderEntity.class)))
			.thenThrow(new DataAccessException("First Ex"))
			.thenThrow(new DataAccessException("Second Ex"));
		
		try{
		this.target.openNewOrder(CUSTOMERID);
		}finally {
			Mockito.verify(orderDao,Mockito.times(2))
			.insert(Mockito.any(OrderEntity.class));
		}
			
	}*/
	
	
	@Test(expected=ServiceException.class)
	public void ttest_openNewOrder_failedDataInsert() throws Exception{
		
		Mockito.when(orderDao.insert(Mockito.any(OrderEntity.class)))
			.thenThrow(new DataAccessException("First Ex"))
			.thenThrow(new DataAccessException("Second Ex"));
		
		
		try{
		this.target.openNewOrder(CUSTOMERID);
		}finally {
			Mockito.verify(orderDao,Mockito.times(2)).insert(Mockito.any(OrderEntity.class));
		}
		
	}
	
	
	@Test
	public void ttest_openNewOrder_Success() throws Exception{
		
		Mockito.when(orderDao.insert(Mockito.any(OrderEntity.class)))
			.thenThrow(new DataAccessException("First Ex"))
			.thenReturn(1);
		
		this.target.openNewOrder(1);
		
		Mockito.verify(orderDao,Mockito.times(2)).insert(Mockito.any(OrderEntity.class));
		
	}
	
	
	@Test
	public void open_NewOrder_Success() throws Exception{
		
		
		Mockito.when(orderDao.insert(Mockito.any(OrderEntity.class))).thenReturn(1);
		
		String orderNo=target.openNewOrder(CUSTOMERID);
		
		
		ArgumentCaptor<OrderEntity> orderEntyCapture=ArgumentCaptor.forClass(OrderEntity.class);
		
		Mockito.verify(orderDao).insert(orderEntyCapture.capture());
		
		OrderEntity orderEntyCap=orderEntyCapture.getValue();
		
		assertNotNull(orderEntyCap);
		assertEquals(CUSTOMERID, orderEntyCap.getCustomerId());
		assertEquals(orderNo, orderEntyCap.getOrderNumber());
	}
	
	
	
	

}
