package org.cap.bank.test;

public interface GoodTestCategory {

}
