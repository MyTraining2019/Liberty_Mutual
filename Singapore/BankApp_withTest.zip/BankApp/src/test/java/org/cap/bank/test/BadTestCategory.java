package org.cap.bank.test;

public interface BadTestCategory {
	
	public void show();

}
