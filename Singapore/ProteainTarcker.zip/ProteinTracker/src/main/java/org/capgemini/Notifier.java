package org.capgemini;

public interface Notifier {
	boolean send(String msg);
}
