package org.capgemini;

public class InvalidGoalException extends Exception {

	public InvalidGoalException(String msg){
		super(msg);
	}
}
