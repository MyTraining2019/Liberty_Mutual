package org.capgemini;

public class NotifierStub implements Notifier {
	
	public boolean send(String msg) 
	{ 
	return true; 
	}
}