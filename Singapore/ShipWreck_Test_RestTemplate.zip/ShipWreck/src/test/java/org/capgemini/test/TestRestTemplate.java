package org.capgemini.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.client.MockRestServiceServer;
import org.springframework.web.client.RestTemplate;
import static org.springframework.test.web.client.RequestMatcher.*;
import static org.springframework.test.web.client.match.MockRestRequestMatchers.requestTo;
import static org.springframework.test.web.client.response.MockRestResponseCreators.*;

import org.capgemini.model.Shipwreck;

import static org.springframework.test.web.client.match.MockRestRequestMatchers.*;
import static org.springframework.test.web.client.ExpectedCount.*;

@RunWith(SpringJUnit4ClassRunner.class)
public class TestRestTemplate {
	
	RestTemplate restTemplate = new RestTemplate();
	
	/*@Mock
	private RestTemplate restTemplate;
	
	@Before
	public void setUp(){
		MockitoAnnotations.initMocks(this);
	}*/

	@Test
	public void test_RestCall() {
		
				 MockRestServiceServer server = MockRestServiceServer.createServer(restTemplate);
						
				 //Mockito.when(accountDao.createAccount(account)).thenReturn(true);

				 server.expect(manyTimes(), requestTo("/api/v1/shipwrecks/42")).andExpect(method(HttpMethod.GET))
								.andRespond(withSuccess("{ \"id\" : \"42\", \"name\" : \"US 430\"}", MediaType.APPLICATION_JSON));

				

				// restTemplate.getForObject("/api/v1/shipwrecks", String.class);
				 
				 Shipwreck shipwreck = restTemplate.getForObject("/api/v1/shipwrecks/{id}", Shipwreck.class, 42);
				 
				 // Use the Shipwreck instance...
				 
				 // Verify all expectations met
				 server.verify();
	}

}
