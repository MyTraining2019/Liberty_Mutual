package org.cap.order.dao.impl;

public class DBInfo {

	public final static String DRIVER = "org.h2.Driver";
	public final static String URL = "jdbc:h2:mem:test";
	public final static String USER = "sa";
	public final static String PASSWORD = "";
}
